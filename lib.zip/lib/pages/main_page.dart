import 'package:english_words/english_words.dart';
import 'package:flutter/material.dart';
import 'favorites_page.dart';
import 'list_all_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final List<WordPair> _suggestions = [];
  final Set<WordPair> _saved = {};
  final List<WordPair> _allPairs = [];

  @override
  void initState() {
    super.initState();
    _loadInitialPairs();
  }

  void _loadInitialPairs() {
    for (int i = 0; i < 10; i++) {
      _addNewPair();
    }
  }

  void _addNewPair() {
    final newPair = WordPair.random();
    _suggestions.add(newPair);
    _allPairs.add(newPair);
  }

  void _loadMorePairs() {
    setState(() {
      _addNewPair();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('WordPair Generator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ListAllPage(pairs: _allPairs)),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.favorite),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => FavoritesPage(saved: _saved)),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: _suggestions.length * 2, 
        itemBuilder: (context, i) {
          if (i.isOdd) return const Divider();
          
          final index = i ~/ 2;
          if (index == _suggestions.length - 1) {
            
            Future.delayed(Duration.zero, _loadMorePairs);
          }
          
          final pair = _suggestions[index];
          final isSaved = _saved.contains(pair);
          
          return ListTile(
            title: Text(pair.asPascalCase),
            trailing: Icon(
              isSaved ? Icons.favorite : Icons.favorite_border,
              color: isSaved ? Colors.red : null,
            ),
            onTap: () {
              setState(() {
                isSaved ? _saved.remove(pair) : _saved.add(pair);
              });
            },
          );
        },
      ),
    );
  }
}