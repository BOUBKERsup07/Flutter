import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';

class FavoritesPage extends StatelessWidget {
  final Set<WordPair> saved;

  const FavoritesPage({super.key, required this.saved});

  @override
  Widget build(BuildContext context) {
    final tiles = saved.map((pair) => ListTile(
          title: Text(pair.asPascalCase),
        ));

    return Scaffold(
      appBar: AppBar(title: const Text('Favorites')),
      body: ListView(children: tiles.toList()),
    );
  }
}