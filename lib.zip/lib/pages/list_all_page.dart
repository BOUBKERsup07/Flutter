import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';

class ListAllPage extends StatelessWidget {
  final List<WordPair> pairs;

  const ListAllPage({super.key, required this.pairs});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('All Generated Pairs')),
      body: ListView.builder(
        itemCount: pairs.length,
        itemBuilder: (context, index) {
          return ListTile(title: Text(pairs[index].asPascalCase));
        },
      ),
    );
  }
}